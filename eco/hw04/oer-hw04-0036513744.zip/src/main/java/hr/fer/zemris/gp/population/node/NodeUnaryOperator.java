package hr.fer.zemris.gp.population.node;

public abstract class NodeUnaryOperator extends NodeOperator{
    public abstract double calculate(double left);
}
